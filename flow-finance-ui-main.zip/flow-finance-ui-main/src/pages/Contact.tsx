
import Footer from '@/components/Footer';

const Contact = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            ExpenseFlow
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-8">Contact Us</h1>
          
          <div className="space-y-8">
            <div className="text-center">
              <p className="text-lg text-gray-600 mb-8">
                Have a question, facing an issue, or need support?
              </p>
              <p className="text-lg text-gray-600">
                We're here to help — whether it's about a course, service, or general inquiry.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Phone */}
              <div className="text-center p-6 bg-blue-50 rounded-xl">
                <div className="text-4xl mb-4">📱</div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Call us</h3>
                <p className="text-gray-600 text-lg font-medium">0312 5700977</p>
              </div>

              {/* Hours */}
              <div className="text-center p-6 bg-green-50 rounded-xl">
                <div className="text-4xl mb-4">🕘</div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Support Hours</h3>
                <p className="text-gray-600">9:00 AM – 5:00 PM</p>
                <p className="text-gray-600">(Monday to Sunday)</p>
              </div>

              {/* Email */}
              <div className="text-center p-6 bg-purple-50 rounded-xl">
                <div className="text-4xl mb-4">📧</div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Email</h3>
                <p className="text-gray-600">courses@theflameignite.com</p>
              </div>
            </div>

            {/* Additional Support Info */}
            <div className="bg-gray-50 rounded-xl p-6 text-center">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Get Quick Support</h3>
              <p className="text-gray-600 mb-4">
                For the fastest response, please email us with:
              </p>
              <ul className="text-left max-w-md mx-auto space-y-2 text-gray-600">
                <li>• Your account email address</li>
                <li>• A detailed description of your issue</li>
                <li>• Screenshots (if applicable)</li>
                <li>• Steps you've already tried</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Contact;
