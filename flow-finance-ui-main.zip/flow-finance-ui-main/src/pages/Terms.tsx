
import Footer from '@/components/Footer';

const Terms = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            ExpenseFlow
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-8 flex items-center">
            📄 Terms of Service
          </h1>
          
          <div className="space-y-6 text-gray-700">
            <div>
              <p className="font-semibold">Effective Date: June 23, 2025</p>
              <p>Website: www.expenseflow.com</p>
              <p>Owner: ExpenseFlow Technologies</p>
            </div>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">1. Acceptance of Terms</h2>
              <p>By accessing or using ExpenseFlow ("Website" or "Service"), including any tools, features, or content provided, you agree to be bound by these Terms of Service ("Terms"). If you do not agree with any part of the Terms, please do not use this Website.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">2. Description of Service</h2>
              <p>ExpenseFlow offers an online platform that allows registered users to record, track, and analyze their personal or business expenses. Features may include dashboards, data visualizations, downloadable reports, and insights into spending behavior.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">3. Eligibility</h2>
              <p>To use this Service, you must:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>Be at least 13 years of age.</li>
                <li>Provide accurate and complete registration information.</li>
                <li>Not share your login credentials with others.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">4. User Accounts</h2>
              <p>You are responsible for keeping your account and password secure. You agree to accept responsibility for all activities that occur under your account. Notify us immediately of any unauthorized use or breach.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">5. Data Privacy</h2>
              <p>We are committed to protecting your data. Your expense information is securely stored and accessible only to you unless you explicitly share it. Please refer to our Privacy Policy for full details.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">6. Prohibited Use</h2>
              <p>You agree not to:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>Use the Website for any unlawful activity.</li>
                <li>Access or attempt to access other users' data.</li>
                <li>Introduce viruses or malicious code.</li>
                <li>Reverse engineer or misuse any part of the platform.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">7. Payments & Subscriptions (If Applicable)</h2>
              <p>If any paid features or subscriptions are offered:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>All fees are disclosed before payment.</li>
                <li>You may cancel anytime, but fees are non-refundable unless otherwise stated.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">8. Modifications to Service</h2>
              <p>We reserve the right to modify or discontinue any part of the Website without notice. We are not liable for any resulting loss or inconvenience.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">9. Termination</h2>
              <p>Your account may be suspended or deleted if you:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>Violate these Terms</li>
                <li>Use the platform fraudulently or abusively</li>
                <li>Compromise the security of the service</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">10. Disclaimer</h2>
              <p>The Website and its content are provided "as is" and "as available." We make no warranties about accuracy, availability, or reliability. Use of the service is at your own risk.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">11. Limitation of Liability</h2>
              <p>To the fullest extent allowed by law, ExpenseFlow Technologies shall not be held liable for any direct, indirect, incidental, or consequential damages arising from your use or inability to use the service.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">12. Changes to Terms</h2>
              <p>We may update these Terms at any time. Continued use of the Website after changes are posted indicates your acceptance of the revised Terms.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">13. Contact Us</h2>
              <p>If you have any questions or concerns about these Terms:</p>
              <p className="mt-2">📧 Email: support@expenseflow.com</p>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Terms;
