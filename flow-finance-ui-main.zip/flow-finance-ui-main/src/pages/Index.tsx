
import { useAuth } from '@/contexts/AuthContext';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import Dashboard from '@/components/Dashboard';
import LoadingSpinner from '@/components/LoadingSpinner';
import PendingApproval from '@/components/PendingApproval';
import { useState } from 'react';

const Index = () => {
  const { user, profile, loading } = useAuth();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  if (loading) {
    return <LoadingSpinner />;
  }

  if (user && profile) {
    if (!profile.is_approved) {
      return <PendingApproval />;
    }
    return <Dashboard />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50 relative overflow-hidden">
      {/* Enhanced Floating Background Elements with improved animations */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Large floating orbs */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/3 w-80 h-80 bg-green-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse delay-2000"></div>
        
        {/* Medium floating elements with enhanced animations */}
        <div className="absolute top-1/3 left-1/4 w-32 h-32 bg-yellow-200 rounded-full mix-blend-multiply filter blur-lg opacity-20 animate-bounce" style={{animationDuration: '4s'}}></div>
        <div className="absolute bottom-1/3 right-1/4 w-40 h-40 bg-pink-200 rounded-full mix-blend-multiply filter blur-lg opacity-25 animate-bounce delay-2000" style={{animationDuration: '3s'}}></div>
        <div className="absolute top-2/3 left-1/2 w-36 h-36 bg-indigo-200 rounded-full mix-blend-multiply filter blur-lg opacity-20 animate-bounce delay-1000" style={{animationDuration: '5s'}}></div>
        
        {/* Small floating particles with varied animations */}
        <div className="absolute top-1/4 right-1/3 w-4 h-4 bg-purple-400 rounded-full opacity-40 animate-ping"></div>
        <div className="absolute bottom-1/4 left-1/2 w-3 h-3 bg-blue-400 rounded-full opacity-50 animate-ping delay-1000"></div>
        <div className="absolute top-3/4 right-1/2 w-5 h-5 bg-green-400 rounded-full opacity-30 animate-ping delay-2000"></div>
        <div className="absolute top-1/2 left-1/5 w-2 h-2 bg-yellow-400 rounded-full opacity-60 animate-ping delay-500"></div>
        <div className="absolute bottom-1/2 right-1/5 w-4 h-4 bg-red-400 rounded-full opacity-35 animate-ping delay-1500"></div>
        
        {/* Floating gradient shapes */}
        <div className="absolute top-10 right-1/3 w-20 h-20 bg-gradient-to-r from-purple-300 to-pink-300 rounded-full opacity-20 animate-pulse delay-3000"></div>
        <div className="absolute bottom-10 left-1/4 w-24 h-24 bg-gradient-to-r from-blue-300 to-green-300 rounded-full opacity-25 animate-pulse delay-4000"></div>
        
        {/* Enhanced moving particles */}
        <div className="absolute top-1/3 right-2/3 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full opacity-40 animate-bounce" style={{animationDuration: '6s', animationDelay: '1s'}}></div>
        <div className="absolute bottom-1/3 left-2/3 w-8 h-8 bg-gradient-to-r from-green-400 to-teal-400 rounded-full opacity-30 animate-bounce" style={{animationDuration: '7s', animationDelay: '2s'}}></div>
        
        {/* Micro particles for depth */}
        <div className="absolute top-16 left-3/4 w-1 h-1 bg-purple-500 rounded-full opacity-70 animate-ping" style={{animationDelay: '3s'}}></div>
        <div className="absolute bottom-20 right-2/3 w-1 h-1 bg-blue-500 rounded-full opacity-60 animate-ping" style={{animationDelay: '4s'}}></div>
        <div className="absolute top-3/4 left-1/3 w-1 h-1 bg-green-500 rounded-full opacity-50 animate-ping" style={{animationDelay: '5s'}}></div>
      </div>

      {/* Animated background grid */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500" style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)',
          backgroundSize: '20px 20px',
          animation: 'float 20s ease-in-out infinite'
        }}></div>
      </div>

      <Hero onOpenAuth={() => setIsAuthModalOpen(true)} />
      <Features />
      <Footer />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
      
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-10px) rotate(180deg); }
        }
      `}</style>
    </div>
  );
};

export default Index;
