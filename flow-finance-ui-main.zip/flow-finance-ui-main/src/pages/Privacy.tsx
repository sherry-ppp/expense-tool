
import Footer from '@/components/Footer';

const Privacy = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            ExpenseFlow
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-8 flex items-center">
            🔒 Privacy Policy
          </h1>
          
          <div className="space-y-6 text-gray-700">
            <div>
              <p className="font-semibold">Effective Date: June 23, 2025</p>
              <p>Website: www.expenseflow.com</p>
              <p>Owner: ExpenseFlow Technologies</p>
            </div>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">1. Introduction</h2>
              <p>At ExpenseFlow, your privacy is extremely important to us. This Privacy Policy explains what personal information we collect, how we use it, and what choices you have regarding your data.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">2. Information We Collect</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-gray-800">🧾 Information You Provide</h3>
                  <ul className="list-disc ml-6 mt-2 space-y-1">
                    <li>Full name, email, and password when you register</li>
                    <li>Expense entries (e.g., amount, date, name, category)</li>
                    <li>Optional: notes, attachments, or comments related to transactions</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">📊 Automatically Collected Data</h3>
                  <ul className="list-disc ml-6 mt-2 space-y-1">
                    <li>Device/browser type</li>
                    <li>IP address and location (if enabled)</li>
                    <li>Usage data such as page visits, actions, and preferences</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">3. How We Use Your Information</h2>
              <p>We use your data to:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>Provide core features like expense tracking and analytics</li>
                <li>Improve our platform's performance and security</li>
                <li>Send you important updates, summaries, or alerts (only with your consent)</li>
                <li>Respond to customer support queries</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">4. Sharing of Data</h2>
              <p>We do not sell or share your personal data with third-party advertisers.</p>
              <p className="mt-2">We may share data only in the following cases:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>With trusted service providers (e.g., hosting or email tools) who assist us in running the site</li>
                <li>If required by law or to comply with legal processes</li>
                <li>To prevent fraud or abuse of the service</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">5. Data Storage & Security</h2>
              <ul className="list-disc ml-6 space-y-1">
                <li>Your data is securely stored using modern encryption methods</li>
                <li>Passwords are hashed and not viewable by anyone (including us)</li>
                <li>We use Supabase and other cloud providers who comply with industry-standard security practices</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">6. Cookies & Analytics</h2>
              <p>We may use cookies or similar tools to:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>Remember your login</li>
                <li>Improve performance and UX</li>
                <li>Understand usage behavior via tools like Google Analytics</li>
              </ul>
              <p className="mt-2">You can disable cookies in your browser settings if you prefer.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">7. Your Rights</h2>
              <p>You have the right to:</p>
              <ul className="list-disc ml-6 mt-2 space-y-1">
                <li>Access your personal data</li>
                <li>Request correction or deletion of your data</li>
                <li>Export your data (CSV or other formats)</li>
                <li>Close your account at any time</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">8. Children's Privacy</h2>
              <p>Our service is not intended for children under 13. We do not knowingly collect personal data from children.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">9. Changes to This Policy</h2>
              <p>We may update this Privacy Policy as needed. When we do, we will revise the "Effective Date" above. Continued use of the service means you agree to the new policy.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">10. Contact Us</h2>
              <p>If you have any questions about this Privacy Policy or how your data is handled:</p>
              <p className="mt-2">📧 Email: support@expenseflow.com</p>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Privacy;
