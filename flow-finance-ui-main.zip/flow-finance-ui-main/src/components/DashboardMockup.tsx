
import { TrendingUp, TrendingDown, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const DashboardMockup = () => {
  const mockTransactions = [
    { id: 1, name: "Grocery Shopping", type: "Expense", amount: -125.50, date: "2024-01-15" },
    { id: 2, name: "Salary Refund", type: "Refund", amount: 2500.00, date: "2024-01-14" },
    { id: 3, name: "Coffee Shop", type: "Expense", amount: -8.75, date: "2024-01-13" },
    { id: 4, name: "Tax Return", type: "Refund", amount: 450.00, date: "2024-01-12" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-6 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-500">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-gray-800">Dashboard Preview</h3>
        <Button size="sm" className="rounded-xl bg-gradient-to-r from-green-500 to-blue-500 text-white">
          <Download className="h-4 w-4 mr-1" />
          Export CSV
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="border-0 bg-gradient-to-br from-red-50 to-red-100 rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-red-600 flex items-center">
              <TrendingDown className="h-4 w-4 mr-1" />
              Total Expenses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-700">$1,234.25</div>
          </CardContent>
        </Card>

        <Card className="border-0 bg-gradient-to-br from-green-50 to-green-100 rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-green-600 flex items-center">
              <TrendingUp className="h-4 w-4 mr-1" />
              Total Refunds
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700">$2,950.00</div>
          </CardContent>
        </Card>
      </div>

      {/* Mini Chart Placeholder */}
      <div className="bg-gradient-to-r from-purple-100 to-blue-100 rounded-2xl p-4 mb-6">
        <h4 className="text-sm font-semibold text-gray-700 mb-3">Cash Flow Trend</h4>
        <div className="h-16 bg-gradient-to-r from-purple-200 to-blue-200 rounded-xl flex items-end justify-between px-2">
          <div className="w-2 bg-purple-500 rounded-t" style={{height: '60%'}}></div>
          <div className="w-2 bg-blue-500 rounded-t" style={{height: '80%'}}></div>
          <div className="w-2 bg-green-500 rounded-t" style={{height: '40%'}}></div>
          <div className="w-2 bg-purple-500 rounded-t" style={{height: '90%'}}></div>
          <div className="w-2 bg-blue-500 rounded-t" style={{height: '70%'}}></div>
        </div>
      </div>

      {/* Sample Transactions */}
      <div className="space-y-3">
        <h4 className="text-sm font-semibold text-gray-700">Recent Transactions</h4>
        {mockTransactions.slice(0, 3).map((transaction) => (
          <div key={transaction.id} className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-xl">
            <div className="flex items-center space-x-3">
              <div className="flex-1">
                <div className="font-medium text-gray-800 text-sm">{transaction.name}</div>
                <div className="flex items-center space-x-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    transaction.type === 'Expense' 
                      ? 'bg-red-100 text-red-600' 
                      : 'bg-green-100 text-green-600'
                  }`}>
                    {transaction.type}
                  </span>
                  <span className="text-xs text-gray-500">{transaction.date}</span>
                </div>
              </div>
            </div>
            <div className={`font-bold text-sm ${
              transaction.amount < 0 ? 'text-red-600' : 'text-green-600'
            }`}>
              {transaction.amount < 0 ? '-' : '+'}${Math.abs(transaction.amount).toFixed(2)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DashboardMockup;
