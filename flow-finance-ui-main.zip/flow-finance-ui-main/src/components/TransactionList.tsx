
import { Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Transaction } from '@/hooks/useTransactions';

interface TransactionListProps {
  transactions: Transaction[];
  onDeleteTransaction: (id: string) => void;
  currency: string;
  loading?: boolean;
}

const TransactionList = ({ transactions, onDeleteTransaction, currency, loading }: TransactionListProps) => {
  const getCurrencySymbol = (curr: string) => {
    const symbols: { [key: string]: string } = {
      USD: '$', PKR: '₨', EUR: '€', GBP: '£', JPY: '¥'
    };
    return symbols[curr] || '$';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-800">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center justify-between p-4 bg-gray-100 rounded-xl">
                  <div className="flex-1">
                    <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-300 rounded w-1/2"></div>
                  </div>
                  <div className="h-6 bg-gray-300 rounded w-20"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-800">Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No transactions found for the selected period.</p>
          ) : (
            transactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200 group"
              >
                <div className="flex-1">
                  <div className="font-semibold text-gray-800">{transaction.name}</div>
                  {transaction.notes && (
                    <div className="text-sm text-gray-600 mt-1 italic">"{transaction.notes}"</div>
                  )}
                  <div className="flex items-center space-x-3 mt-1">
                    <span
                      className={`text-xs px-3 py-1 rounded-full font-medium ${
                        transaction.type === 'expense'
                          ? 'bg-red-100 text-red-600'
                          : 'bg-green-100 text-green-600'
                      }`}
                    >
                      {transaction.type === 'expense' ? 'Expense' : 'Refund'}
                    </span>
                    <span className="text-sm text-gray-500">{formatDate(transaction.date)}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div
                    className={`font-bold text-lg ${
                      transaction.type === 'expense' ? 'text-red-600' : 'text-green-600'
                    }`}
                  >
                    {transaction.type === 'expense' ? '-' : '+'}
                    {getCurrencySymbol(currency)}{Math.abs(transaction.amount).toFixed(2)}
                  </div>
                  
                  <Button
                    onClick={() => onDeleteTransaction(transaction.id)}
                    variant="ghost"
                    size="sm"
                    className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-xl"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default TransactionList;
