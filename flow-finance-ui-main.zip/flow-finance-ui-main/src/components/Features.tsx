
import { Activity, Plus, Download, Smartphone } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: Activity,
      title: "Visual Reports",
      description: "Dynamic charts that update in real time to show your spending patterns and trends.",
      bgColor: "bg-green-500",
      iconBg: "bg-green-100"
    },
    {
      icon: Plus,
      title: "Smart Entry",
      description: "Add expenses or refunds quickly with amount, type, and date in just a few clicks.",
      bgColor: "bg-blue-500",
      iconBg: "bg-blue-100"
    },
    {
      icon: Download,
      title: "Export CSV",
      description: "One-click download of your complete transaction history for record keeping.",
      bgColor: "bg-purple-500",
      iconBg: "bg-purple-100"
    },
    {
      icon: Smartphone,
      title: "Mobile Ready",
      description: "Access your expense data anywhere with our fully responsive mobile interface.",
      bgColor: "bg-pink-500",
      iconBg: "bg-pink-100"
    }
  ];

  return (
    <section className="py-20 px-4 relative z-10">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Everything you need to manage expenses
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Powerful features designed to make expense tracking effortless and insightful
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              {/* Icon */}
              <div className={`w-16 h-16 ${feature.iconBg} rounded-2xl mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className={`w-8 h-8 text-${feature.bgColor.split('-')[1]}-600`} />
              </div>
              
              {/* Content */}
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
