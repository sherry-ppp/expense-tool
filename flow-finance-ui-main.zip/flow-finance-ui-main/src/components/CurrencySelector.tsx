
import { DollarSign } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface CurrencySelectorProps {
  currency: string;
  onCurrencyChange: (currency: string) => void;
}

const CurrencySelector = ({ currency, onCurrencyChange }: CurrencySelectorProps) => {
  const currencies = [
    { code: 'USD', name: 'US Dollar', symbol: '$' },
    { code: 'PKR', name: 'Pakistani Rupee', symbol: '₨' },
    { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
    { code: 'EUR', name: 'Euro', symbol: '€' },
    { code: 'GBP', name: 'British Pound', symbol: '£' },
    { code: 'JPY', name: 'Japanese Yen', symbol: '¥' },
  ];

  const selectedCurrency = currencies.find(c => c.code === currency);

  return (
    <div className="flex items-center space-x-2">
      <DollarSign className="h-4 w-4 text-gray-500" />
      <Select value={currency} onValueChange={onCurrencyChange}>
        <SelectTrigger className="w-32 rounded-xl border-gray-200 focus:border-purple-500 bg-white/80">
          <SelectValue>
            <span className="flex items-center space-x-1">
              <span>{selectedCurrency?.symbol}</span>
              <span>{selectedCurrency?.code}</span>
            </span>
          </SelectValue>
        </SelectTrigger>
        <SelectContent className="bg-white border-gray-200 rounded-xl">
          {currencies.map((curr) => (
            <SelectItem key={curr.code} value={curr.code}>
              <div className="flex items-center space-x-2">
                <span>{curr.symbol}</span>
                <span>{curr.code}</span>
                <span className="text-sm text-gray-500">- {curr.name}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default CurrencySelector;
