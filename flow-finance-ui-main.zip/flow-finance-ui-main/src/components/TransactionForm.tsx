
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface TransactionFormProps {
  onAddTransaction: (transaction: {
    name: string;
    amount: number;
    type: 'expense' | 'refund';
    date: string;
    notes?: string;
  }) => void;
  currency: string;
}

const TransactionForm = ({ onAddTransaction, currency }: TransactionFormProps) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'expense' | 'refund'>('expense');
  const [date, setDate] = useState<Date>(new Date());
  const [notes, setNotes] = useState('');

  const getCurrencySymbol = (curr: string) => {
    const symbols: { [key: string]: string } = {
      USD: '$', PKR: '₨', EUR: '€', GBP: '£', JPY: '¥'
    };
    return symbols[curr] || '$';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !amount || !date) return;

    const numAmount = parseFloat(amount);

    onAddTransaction({
      name,
      amount: numAmount,
      type,
      date: date.toISOString(),
      notes: notes.trim() || undefined,
    });

    // Reset form
    setName('');
    setAmount('');
    setType('expense');
    setDate(new Date());
    setNotes('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Transaction Name</Label>
        <Input
          id="name"
          type="text"
          placeholder="e.g., Coffee shop"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="rounded-xl border-gray-200 focus:border-purple-500"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Amount ({getCurrencySymbol(currency)})</Label>
        <Input
          id="amount"
          type="number"
          step="0.01"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="rounded-xl border-gray-200 focus:border-purple-500"
          required
        />
      </div>

      <div className="space-y-2">
        <Label>Type</Label>
        <Select value={type} onValueChange={(value: 'expense' | 'refund') => setType(value)}>
          <SelectTrigger className="rounded-xl border-gray-200 focus:border-purple-500">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-white border-gray-200 rounded-xl">
            <SelectItem value="expense">Expense</SelectItem>
            <SelectItem value="refund">Refund</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal rounded-xl border-gray-200 focus:border-purple-500",
                !date && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date ? format(date, "PPP") : <span>Pick a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={date}
              onSelect={(selectedDate) => selectedDate && setDate(selectedDate)}
              initialFocus
              className={cn("p-3 pointer-events-auto")}
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Add a note (optional)</Label>
        <Textarea
          id="notes"
          placeholder="e.g., dinner with friends"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="rounded-xl border-gray-200 focus:border-purple-500 min-h-[80px]"
          rows={3}
        />
      </div>

      <Button 
        type="submit" 
        className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 rounded-xl text-white py-3"
      >
        Add Transaction
      </Button>
    </form>
  );
};

export default TransactionForm;
