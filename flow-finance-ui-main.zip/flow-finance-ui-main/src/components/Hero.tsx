
import { ArrowRight, Phone, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import DashboardMockup from './DashboardMockup';

interface HeroProps {
  onOpenAuth: () => void;
}

const Hero = ({ onOpenAuth }: HeroProps) => {
  const handleContactClick = () => {
    const contactInfo = `
📱 Call us: 0312 5700977
🕘 Support Hours: 9:00 AM – 5:00 PM (Daily)
📧 Email: support@expenseflow.com

We're here to help with any questions or support needs!
    `;
    alert(contactInfo);
  };

  return (
    <div className="container mx-auto px-4 py-8 relative z-10">
      {/* Header with Login */}
      <div className="flex justify-between items-center mb-8">
        <div></div>
        <Button 
          onClick={onOpenAuth}
          variant="outline"
          className="border-2 border-purple-200 text-purple-600 hover:border-purple-500 hover:bg-purple-50 px-6 py-2 rounded-xl transition-all duration-300"
        >
          <User className="mr-2 h-4 w-4" />
          Login
        </Button>
      </div>

      <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen">
        {/* Left Side - Hero Content */}
        <div className="space-y-8 text-center lg:text-left relative">
          {/* Floating Animation Elements */}
          <div className="absolute -top-10 -left-10 w-20 h-20 bg-purple-200 rounded-full opacity-60 animate-bounce" style={{animationDelay: '0s', animationDuration: '3s'}}></div>
          <div className="absolute top-20 -right-5 w-16 h-16 bg-blue-200 rounded-full opacity-50 animate-bounce" style={{animationDelay: '1s', animationDuration: '4s'}}></div>
          <div className="absolute bottom-10 left-20 w-12 h-12 bg-green-200 rounded-full opacity-40 animate-bounce" style={{animationDelay: '2s', animationDuration: '3.5s'}}></div>

          {/* Logo with floating animation */}
          <div className="space-y-2 transform hover:scale-105 transition-transform duration-300">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-green-600 bg-clip-text text-transparent animate-pulse">
              ExpenseFlow
            </h1>
            <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-green-500 mx-auto lg:mx-0 rounded-full animate-pulse"></div>
          </div>

          {/* Headlines with slide-in animation */}
          <div className="space-y-4 animate-fade-in">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-800 leading-tight">
              Track your spending.
              <br />
              <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                Simplify your finances.
              </span>
            </h2>
            <p className="text-lg md:text-xl text-gray-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
              Easily manage your expenses and refunds with real-time visual tracking and export features.
            </p>
          </div>

          {/* Buttons with hover animations */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <Button 
              onClick={onOpenAuth}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 text-lg rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
            >
              Sign Up Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              onClick={handleContactClick}
              variant="outline"
              className="border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 px-8 py-3 text-lg rounded-2xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
            >
              <Phone className="mr-2 h-5 w-5" />
              Contact Us
            </Button>
          </div>

          {/* Trust Indicators with floating animation */}
          <div className="flex flex-wrap justify-center lg:justify-start gap-6 pt-4">
            <div className="flex items-center space-x-2 text-gray-500 transform hover:scale-110 transition-transform duration-300">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm">Real-time tracking</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-500 transform hover:scale-110 transition-transform duration-300">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
              <span className="text-sm">Export to CSV</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-500 transform hover:scale-110 transition-transform duration-300">
              <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
              <span className="text-sm">Multi-currency</span>
            </div>
          </div>
        </div>

        {/* Right Side - Dashboard Mockup with floating animation */}
        <div className="lg:pl-8 transform hover:scale-105 transition-transform duration-500">
          <DashboardMockup />
        </div>
      </div>
    </div>
  );
};

export default Hero;
