import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Transaction } from '@/hooks/useTransactions';

interface CashFlowChartProps {
  transactions: Transaction[];
  currency: string;
}

const CashFlowChart = ({ transactions, currency }: CashFlowChartProps) => {
  const getCurrencySymbol = (curr: string) => {
    const symbols: { [key: string]: string } = {
      USD: '$', PKR: '₨', EUR: '€', GBP: '£', JPY: '¥'
    };
    return symbols[curr] || '$';
  };

  // Sort transactions by date and calculate running balance
  const sortedTransactions = [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  let runningBalance = 0;
  const chartData = sortedTransactions.map((transaction) => {
    runningBalance += transaction.amount;
    return {
      date: transaction.date,
      balance: runningBalance,
      transaction: transaction.name,
    };
  });

  // Add starting point if we have data
  if (chartData.length > 0) {
    chartData.unshift({
      date: chartData[0].date,
      balance: 0,
      transaction: 'Starting Point',
    });
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-800">Cash Flow Trend</CardTitle>
      </CardHeader>
      <CardContent>
        {chartData.length > 1 ? (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e7ff" />
                <XAxis 
                  dataKey="date" 
                  stroke="#6b7280"
                  fontSize={12}
                  tickFormatter={(value) => new Date(value).toLocaleDateString()}
                />
                <YAxis 
                  stroke="#6b7280"
                  fontSize={12}
                  tickFormatter={(value) => `${getCurrencySymbol(currency)}${value.toFixed(0)}`}
                />
                <Tooltip 
                  formatter={(value: number) => [`${getCurrencySymbol(currency)}${value.toFixed(2)}`, 'Balance']}
                  labelFormatter={(label) => `Date: ${new Date(label).toLocaleDateString()}`}
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: 'none',
                    borderRadius: '12px',
                    boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)',
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="balance" 
                  stroke="url(#colorGradient)" 
                  strokeWidth={3}
                  dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, fill: '#8b5cf6' }}
                />
                <defs>
                  <linearGradient id="colorGradient" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="50%" stopColor="#3b82f6" />
                    <stop offset="100%" stopColor="#10b981" />
                  </linearGradient>
                </defs>
              </LineChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                📊
              </div>
              <p>Add more transactions to see your cash flow trend</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CashFlowChart;
