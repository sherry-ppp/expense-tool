import { useState, useMemo } from 'react';
import { Download, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Transaction } from '@/hooks/useTransactions';

interface MonthlySummaryReportProps {
  transactions: Transaction[];
  currency: string;
  startDate?: Date;
  endDate?: Date;
}

const MonthlySummaryReport = ({ transactions, currency, startDate, endDate }: MonthlySummaryReportProps) => {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);

  const getCurrencySymbol = (curr: string) => {
    const symbols: { [key: string]: string } = {
      USD: '$', PKR: '₨', AUD: 'A$', EUR: '€', GBP: '£', JPY: '¥'
    };
    return symbols[curr] || '$';
  };

  const monthlyData = useMemo(() => {
    const start = startDate || new Date();
    const end = endDate || new Date();

    const startMonth = start.toLocaleString('en-US', { month: 'long' });
    const startYear = start.getFullYear();
    const endMonth = end.toLocaleString('en-US', { month: 'long' });
    const endYear = end.getFullYear();

    let reportTitle: string;

    if (startYear === endYear) {
      reportTitle = startMonth === endMonth
        ? `${startMonth} ${startYear}`
        : `${startMonth} - ${endMonth} ${startYear}`;
    } else {
      reportTitle = `${startMonth} ${startYear} - ${endMonth} ${endYear}`;
    }
    
    const expenses = transactions.filter(t => t.type === 'expense');
    const refunds = transactions.filter(t => t.type === 'refund');
    
    const totalSpent = expenses.reduce((sum, t) => sum + Math.abs(t.amount), 0);
    const totalRefunds = refunds.reduce((sum, t) => sum + t.amount, 0);
    const netSpend = totalSpent - totalRefunds;
    
    const timeDiff = Math.abs(end.getTime() - start.getTime());
    const dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
    const averageSpendPerDay = dayDiff > 0 ? totalSpent / dayDiff : 0;
    
    const biggestTransaction = transactions.reduce((max, t) => 
      Math.abs(t.amount) > Math.abs(max.amount) ? t : max, 
      transactions[0] || { name: 'N/A', amount: 0, date: '', type: 'expense' as const }
    );
    
    const daySpending = transactions.reduce((acc, t) => {
      const day = new Date(t.date).toLocaleDateString();
      acc[day] = (acc[day] || 0) + Math.abs(t.amount);
      return acc;
    }, {} as Record<string, number>);
    
    const mostActiveDay = Object.entries(daySpending).reduce((max, [day, amount]) => 
      amount > max.amount ? { day, amount } : max, 
      { day: 'N/A', amount: 0 }
    );

    return {
      reportTitle,
      totalSpent,
      totalRefunds,
      netSpend,
      averageSpendPerDay,
      biggestTransaction,
      mostActiveDay
    };
  }, [transactions, currency, startDate, endDate]);

  const generateReport = async () => {
    setIsGenerating(true);
    
    toast({
      title: "Generating your report...",
      description: "Please wait while we prepare your monthly summary",
    });

    setTimeout(() => {
      const csvContent = [
        'Summary Report',
        `Period: ${monthlyData.reportTitle}`,
        '',
        'Summary:',
        `Total Spent,${getCurrencySymbol(currency)}${monthlyData.totalSpent.toFixed(2)}`,
        `Total Refunds,${getCurrencySymbol(currency)}${monthlyData.totalRefunds.toFixed(2)}`,
        `Net Spend,${getCurrencySymbol(currency)}${monthlyData.netSpend.toFixed(2)}`,
        `Average Spend Per Day,${getCurrencySymbol(currency)}${monthlyData.averageSpendPerDay.toFixed(2)}`,
        '',
        'Details:',
        `Biggest Transaction,"${monthlyData.biggestTransaction.name}",${getCurrencySymbol(currency)}${Math.abs(monthlyData.biggestTransaction.amount).toFixed(2)},${new Date(monthlyData.biggestTransaction.date).toLocaleDateString()}`,
        `Most Active Day,${monthlyData.mostActiveDay.day},${getCurrencySymbol(currency)}${monthlyData.mostActiveDay.amount.toFixed(2)}`,
        '',
        'All Transactions:',
        'Name,Type,Amount,Date',
        ...transactions.map(t => 
          `"${t.name}",${t.type},${getCurrencySymbol(currency)}${t.amount.toFixed(2)},${new Date(t.date).toLocaleDateString()}`
        )
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `summary-report-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);

      toast({
        title: "✅ Done! Download complete",
        description: "Your summary report has been downloaded",
      });
      
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl rounded-2xl overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-b border-purple-100 p-4">
        <CardTitle className="flex items-center space-x-2 text-lg font-bold text-gray-800">
          <div className="p-1.5 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
            <FileText className="h-4 w-4 text-white" />
          </div>
          <span>Summary Report</span>
        </CardTitle>
        <p className="text-sm text-gray-600 ml-9">For {monthlyData.reportTitle}</p>
      </CardHeader>
      <CardContent className="p-4 space-y-4">
        {/* Key Insights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Average Spend Per Day */}
          <div className="bg-indigo-50 p-3 rounded-xl border border-indigo-100">
            <p className="text-xs font-medium text-indigo-600 mb-1">Avg. Spend/Day</p>
            <p className="text-xl font-bold text-indigo-700">
              {getCurrencySymbol(currency)}{monthlyData.averageSpendPerDay.toFixed(2)}
            </p>
          </div>
          
          {/* Biggest Transaction */}
          <div className="bg-orange-50 p-3 rounded-xl border border-orange-100">
            <p className="text-xs font-medium text-orange-600 mb-1">Biggest Purchase</p>
            <p className="text-base font-bold text-orange-700 truncate" title={monthlyData.biggestTransaction.name}>
              {monthlyData.biggestTransaction.name}
            </p>
            <p className="text-sm font-bold text-orange-800">
              {getCurrencySymbol(currency)}{Math.abs(monthlyData.biggestTransaction.amount).toFixed(2)}
            </p>
          </div>
          
          {/* Most Active Spending Day */}
          <div className="bg-green-50 p-3 rounded-xl border border-green-100">
            <p className="text-xs font-medium text-green-600 mb-1">Busiest Day</p>
            <p className="text-base font-bold text-green-700">
              {monthlyData.mostActiveDay.day}
            </p>
            <p className="text-sm font-bold text-green-800">
              {getCurrencySymbol(currency)}{monthlyData.mostActiveDay.amount.toFixed(2)}
            </p>
          </div>
        </div>

        {/* Download Button */}
        <Button
          onClick={generateReport}
          disabled={isGenerating}
          className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
        >
          <Download className="h-4 w-4 mr-2" />
          {isGenerating ? 'Generating...' : 'Download Report'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default MonthlySummaryReport;
