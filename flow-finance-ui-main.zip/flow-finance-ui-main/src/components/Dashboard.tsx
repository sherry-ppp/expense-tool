import { useState, useMemo } from 'react';
import { Plus, LogOut, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import TransactionForm from './TransactionForm';
import TransactionList from './TransactionList';
import CashFlowChart from './CashFlowChart';
import CurrencySelector from './CurrencySelector';
import DateFilter from './DateFilter';
import MonthlySummaryReport from './MonthlySummaryReport';
import { useAuth } from '@/contexts/AuthContext';
import { useTransactions } from '@/hooks/useTransactions';

const Dashboard = () => {
  const { profile, signOut } = useAuth();
  const { transactions, loading, addTransaction, deleteTransaction, exportToCSV } = useTransactions();
  const [showMobileForm, setShowMobileForm] = useState(false);
  const [currency, setCurrency] = useState('USD');
  const [dateFilter, setDateFilter] = useState<{
    type: 'this-month' | 'last-month' | 'custom-range';
    startDate?: Date;
    endDate?: Date;
  }>({ type: 'this-month' });

  const dateRange = useMemo(() => {
    const now = new Date();
    let startDate: Date;
    let endDate: Date;

    switch (dateFilter.type) {
      case 'last-month':
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        endDate = new Date(now.getFullYear(), now.getMonth(), 0);
        break;
      case 'custom-range':
        startDate = dateFilter.startDate || new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = dateFilter.endDate || new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
      case 'this-month':
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        break;
    }
    return { startDate, endDate };
  }, [dateFilter]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      const transactionDate = new Date(transaction.date);
      return transactionDate >= dateRange.startDate && transactionDate <= dateRange.endDate;
    });
  }, [transactions, dateRange]);

  const totalExpenses = filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);

  const totalRefunds = filteredTransactions
    .filter(t => t.type === 'refund')
    .reduce((sum, t) => sum + t.amount, 0);

  const getCurrencySymbol = (curr: string) => {
    const symbols: { [key: string]: string } = {
      USD: '$', PKR: '₨', AUD: 'A$', EUR: '€', GBP: '£', JPY: '¥'
    };
    return symbols[curr] || '$';
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50 relative overflow-hidden">
      {/* Floating Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/3 w-80 h-80 bg-green-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-2000"></div>
      </div>

      {/* Header */}
      <div className="relative z-10 bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                ExpenseFlow
              </h1>
              <CurrencySelector currency={currency} onCurrencyChange={setCurrency} />
            </div>
            <div className="flex items-center space-x-4">
              <Button
                onClick={exportToCSV}
                variant="outline"
                className="hidden sm:flex items-center space-x-2 rounded-xl"
              >
                <Download className="h-4 w-4" />
                <span>Export CSV</span>
              </Button>
              <Button
                onClick={signOut}
                variant="outline"
                className="flex items-center space-x-2 rounded-xl"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Greeting Banner */}
      <div className="relative z-10 container mx-auto px-4 py-6">
        <div className="bg-gradient-to-r from-purple-100 to-blue-100 rounded-2xl p-6 mb-6">
          <h2 className="text-xl md:text-2xl font-semibold text-gray-800">
            {getGreeting()}, {profile?.full_name}! 👋
          </h2>
          <p className="text-gray-600 mt-1">Here's your latest spending summary.</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 pb-20">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Panel - Transaction Form */}
          <div className="lg:col-span-1">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-800">Add Transaction</CardTitle>
              </CardHeader>
              <CardContent>
                <TransactionForm onAddTransaction={addTransaction} currency={currency} />
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Dashboard Data */}
          <div className="lg:col-span-2 space-y-6">
            {/* Date Filter */}
            <DateFilter onFilterChange={setDateFilter} />

            {/* Monthly Summary Report - NEW */}
            <MonthlySummaryReport 
              transactions={filteredTransactions} 
              currency={currency} 
              startDate={dateRange.startDate}
              endDate={dateRange.endDate}
            />

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="border-0 bg-gradient-to-br from-red-50 to-red-100 rounded-2xl shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-red-600">Total Expenses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-red-700">
                    {getCurrencySymbol(currency)}{totalExpenses.toFixed(2)}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 bg-gradient-to-br from-green-50 to-green-100 rounded-2xl shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-green-600">Total Refunds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-700">
                    {getCurrencySymbol(currency)}{totalRefunds.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Cash Flow Chart */}
            <CashFlowChart transactions={filteredTransactions} currency={currency} />

            {/* Transactions List */}
            <TransactionList 
              transactions={filteredTransactions} 
              onDeleteTransaction={deleteTransaction}
              currency={currency}
              loading={loading}
            />
          </div>
        </div>
      </div>

      {/* Mobile Floating Action Button */}
      <Button
        onClick={() => setShowMobileForm(true)}
        className="lg:hidden fixed bottom-6 right-6 w-14 h-14 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg z-50"
      >
        <Plus className="h-6 w-6" />
      </Button>

      {/* Mobile Transaction Form Modal */}
      {showMobileForm && (
        <div className="lg:hidden fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="bg-white rounded-t-3xl w-full p-6 animate-slide-in-right">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Add Transaction</h3>
              <Button
                onClick={() => setShowMobileForm(false)}
                variant="ghost"
                className="rounded-full"
              >
                ✕
              </Button>
            </div>
            <TransactionForm 
              onAddTransaction={(transaction) => {
                addTransaction(transaction);
                setShowMobileForm(false);
              }} 
              currency={currency}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
