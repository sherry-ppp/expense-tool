import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface DateFilterProps {
  onFilterChange: (filter: {
    type: 'this-month' | 'last-month' | 'custom-range';
    startDate?: Date;
    endDate?: Date;
  }) => void;
}

const DateFilter = ({ onFilterChange }: DateFilterProps) => {
  const [filterType, setFilterType] = useState<'this-month' | 'last-month' | 'custom-range'>('this-month');
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [endDate, setEndDate] = useState<Date | undefined>();

  useEffect(() => {
    if (filterType === 'custom-range') {
      onFilterChange({ type: 'custom-range', startDate, endDate });
    } else {
      onFilterChange({ type: filterType });
    }
  }, [filterType, startDate, endDate, onFilterChange]);


  const handleFilterTypeChange = (value: 'this-month' | 'last-month' | 'custom-range') => {
    setFilterType(value);
  };

  const handleStartDateSelect = (date: Date | undefined) => {
    setStartDate(date);
  }

  const handleEndDateSelect = (date: Date | undefined) => {
    setEndDate(date);
  }


  return (
    <div className="bg-white/80 backdrop-blur-sm border-0 shadow-lg rounded-2xl p-4 mb-6">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
        <div className="flex items-center space-x-2">
          <label className="text-sm font-medium text-gray-700">Filter by:</label>
          <Select value={filterType} onValueChange={handleFilterTypeChange}>
            <SelectTrigger className="w-[160px] rounded-xl border-gray-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-white border-gray-200 rounded-xl">
              <SelectItem value="this-month">This Month</SelectItem>
              <SelectItem value="last-month">Last Month</SelectItem>
              <SelectItem value="custom-range">Custom Range</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {filterType === 'custom-range' && (
          <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">From:</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[140px] justify-start text-left font-normal rounded-xl border-gray-200",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "MMM dd") : "Start"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={handleStartDateSelect}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">To:</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[140px] justify-start text-left font-normal rounded-xl border-gray-200",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "MMM dd") : "End"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={handleEndDateSelect}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DateFilter;
