
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export interface Transaction {
  id: string;
  name: string;
  amount: number;
  type: 'expense' | 'refund';
  date: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export const useTransactions = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchTransactions = async () => {
    if (!user) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('date', { ascending: false });

      if (error) {
        console.error('Error fetching transactions:', error);
        toast({
          title: "Error",
          description: "Failed to load transactions",
          variant: "destructive",
        });
        return;
      }

      // Type cast the data to ensure proper typing
      const typedTransactions = (data || []).map(transaction => ({
        ...transaction,
        type: transaction.type as 'expense' | 'refund'
      }));

      setTransactions(typedTransactions);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const addTransaction = async (transaction: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('transactions')
        .insert([
          {
            ...transaction,
            user_id: user.id
          }
        ])
        .select()
        .single();

      if (error) {
        console.error('Error adding transaction:', error);
        toast({
          title: "Error",
          description: "Failed to add transaction",
          variant: "destructive",
        });
        return;
      }

      // Type cast the returned data
      const typedTransaction = {
        ...data,
        type: data.type as 'expense' | 'refund'
      };

      setTransactions(prev => [typedTransaction, ...prev]);
      toast({
        title: "Success!",
        description: `${transaction.type === 'expense' ? 'Expense' : 'Refund'} added successfully`,
      });
    } catch (error) {
      console.error('Error adding transaction:', error);
    }
  };

  const deleteTransaction = async (id: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('transactions')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('Error deleting transaction:', error);
        toast({
          title: "Error",
          description: "Failed to delete transaction",
          variant: "destructive",
        });
        return;
      }

      setTransactions(prev => prev.filter(t => t.id !== id));
      toast({
        title: "Deleted",
        description: "Transaction removed successfully",
      });
    } catch (error) {
      console.error('Error deleting transaction:', error);
    }
  };

  const exportToCSV = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase.rpc('export_user_transactions_csv', {
        user_uuid: user.id
      });

      if (error) {
        console.error('Error exporting CSV:', error);
        toast({
          title: "Error",
          description: "Failed to export transactions",
          variant: "destructive",
        });
        return;
      }

      const blob = new Blob([data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `expenses-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);

      toast({
        title: "Export Complete",
        description: "Your transactions have been exported to CSV",
      });
    } catch (error) {
      console.error('Error exporting CSV:', error);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [user]);

  return {
    transactions,
    loading,
    addTransaction,
    deleteTransaction,
    exportToCSV,
    refetch: fetchTransactions
  };
};
